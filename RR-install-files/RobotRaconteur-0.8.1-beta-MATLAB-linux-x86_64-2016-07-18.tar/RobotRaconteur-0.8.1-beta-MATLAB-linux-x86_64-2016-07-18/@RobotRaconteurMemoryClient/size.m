function n=size(obj)

n=RobotRaconteurMex('MemoryOp',obj.rrobjecttype,obj.rrstubid,obj.rrmembername,'size');