function c=RobotRaconteurObject(objecttype,stubid)

c=struct;
c.rrobjecttype=objecttype;
c.rrstubid=stubid;

c=class(c,'RobotRaconteurObject');
