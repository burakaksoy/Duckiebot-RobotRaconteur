function disp(c)

    display(c)