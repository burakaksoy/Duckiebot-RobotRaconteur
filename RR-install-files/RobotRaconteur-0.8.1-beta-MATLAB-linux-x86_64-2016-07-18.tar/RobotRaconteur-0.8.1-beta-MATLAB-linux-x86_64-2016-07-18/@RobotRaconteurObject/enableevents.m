function enableevents(obj)

RobotRaconteurMex('enableevents',obj.rrobjecttype,obj.rrstubid);