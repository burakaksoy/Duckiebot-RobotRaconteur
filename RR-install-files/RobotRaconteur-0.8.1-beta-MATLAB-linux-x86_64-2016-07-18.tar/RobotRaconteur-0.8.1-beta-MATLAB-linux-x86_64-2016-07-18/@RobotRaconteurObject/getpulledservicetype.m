function def=getpulledservicetype(obj,name)

def=RobotRaconteurMex('GetPulledServiceType',obj.rrobjecttype,obj.rrstubid,name);