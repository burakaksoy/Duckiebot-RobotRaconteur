function lockop(obj,command)

RobotRaconteurMex('LockOp',obj.rrobjecttype,obj.rrstubid,command);
