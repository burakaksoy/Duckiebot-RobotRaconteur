function mem=members(obj)

mem=RobotRaconteurMex('members',obj.rrobjecttype,obj.rrstubid);
