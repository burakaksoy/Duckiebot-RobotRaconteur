function t=type(obj)

t=RobotRaconteurMex('type',obj.rrobjecttype,obj.rrstubid);