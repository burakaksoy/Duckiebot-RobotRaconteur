#  Robot Raconteur(R) - A communication library for robotics and automation systems
#  Copyright (C) 2014 John Wason <wason@wasontech.com>
#                     Wason Technology, LLC
#
#  This program is released under the terms of the Robot Raconteur(R)
#  license.  Full text can be found at  http://robotraconteur.com/license2 .
#  Attribute to this library as "Robot Raconteur(R)" in documentation or
#  packaging.  This software is royalty free for commercial use under
#  the conditions of the license.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

import struct
import ctypes
import RobotRaconteurPython
from RobotRaconteurPythonDataTypes import *
import operator
import traceback
import threading
import functools
import sys
import warnings
import RobotRaconteurPythonError as RRE

try:
    import numpy
except:
    pass

hastwisted=False

try:
    import twisted.internet.defer.Deferred as Deferred
    import twisted.internet.reactor as reactor
    hastwisted=True
except:
    pass

def SplitQualifiedName(name):
    pos=name.rfind('.')
    if (pos==-1): raise Exception("Name is not qualified")
    return (name[0:pos],name[pos+1:])

def FindStructureByName(l,name):
    for i in l:
        if (i.Name==name):
            return i
    raise RobotRaconteurPythonError.ServiceException("Structure " + name + " not found")

def FindMemberByName(l,name):
    for i in l:
        if (i.Name==name):
            return i
    raise RobotRaconteurPythonError.MemberNotFoundException("Member " + name + " not found")

def FindMessageElementByName(l,name):
    for i in l:
        if (i.ElementName==name):
            return i
    raise RobotRaconteurPythonError.MessageElementNotFoundException("Element " + name + " not found")

def PackMessageElement(data,type1,obj=None,node=None):

    if (node is None):
        node=RobotRaconteurPython.RobotRaconteurNode.s

    if (isinstance(type1,str)):
        if (len(type1.split())==1): type1=type1+ " value"
        type2=RobotRaconteurPython.TypeDefinition()
        type2.FromString(type1)
        type1=type2

    if (type1.Type==RobotRaconteurPython.DataTypes_varvalue_t and not type1.IsMap and not type1.IsList):
        dt=data.datatype
        if (len(dt.split())==1): dt=dt + " value"
        type1=RobotRaconteurPython.TypeDefinition()
        type1.FromString(dt)
        data=data.data

    element=RobotRaconteurPython.MessageElement()
    element.ElementName=type1.Name

    if (data is None):

        if(type1.Type>=RobotRaconteurPython.DataTypes_double_t and type1.Type <= RobotRaconteurPython.DataTypes_uint64_t):
            if (type1.Length==0 and not type1.VarLength): raise Exception("Fixed length array must not be None")

        if (type1.Type==RobotRaconteurPython.DataTypes_multidimarray_t):
            if (not type1.VarLength): raise Exception("Fixed dimension array must not be None")

        element.ElementType=RobotRaconteurPython.DataTypes_void_t
        element.DataCount=0
        element.SetData(None)
        return element

    elif (type1.IsList):
        type2=RobotRaconteurPython.TypeDefinition()
        type2.FromString(type1.ToString())
        type2.IsList=False
        type2.KeyType=0

        element.ElementType=RobotRaconteurPython.DataTypes_list_t
        iset=RobotRaconteurPython.vectorptr_messageelement()

        i=0
        for v in data:
            el=PackMessageElement(v,type2,obj,node=node)
            el.ElementName=str(i)
            iset.append(el)
            i=i+1

        element.DataCount=len(iset)
        element.SetData(RobotRaconteurPython.MessageElementList(iset))
        return element


    elif (type1.IsMap):
        type2=RobotRaconteurPython.TypeDefinition()
        type2.FromString(type1.ToString())
        type2.IsMap=False
        type2.KeyType=0
        if (type1.KeyType==RobotRaconteurPython.DataTypes_int32_t):
            element.ElementType=RobotRaconteurPython.DataTypes_vector_t
            iset=RobotRaconteurPython.vectorptr_messageelement()
            if ((type(data) is list) or (type(data) is set) or (type(data) is tuple)):
                i=0
                for v in data:
                    el=PackMessageElement(v,type2,obj,node=node)
                    el.ElementName=str(i)
                    iset.append(el)
                    i=i+1
            else:
                for k in data:
                    el=PackMessageElement(data[k],type2,obj,node=node)
                    el.ElementName=str(k)
                    iset.append(el)
            element.DataCount=len(iset)
            element.SetData(RobotRaconteurPython.MessageElementMap_int32_t(iset))
            return element
        elif (type1.KeyType==RobotRaconteurPython.DataTypes_string_t):
            element.ElementType=RobotRaconteurPython.DataTypes_dictionary_t
            iset=RobotRaconteurPython.vectorptr_messageelement()
            for k in data:
                el=PackMessageElement(data[k],type2,obj,node=node)
                el.ElementName=(k).encode('utf-8')
                iset.append(el)
            element.DataCount=len(iset)

            element.SetData(RobotRaconteurPython.MessageElementMap_string(iset))
            return element

        else:
            raise Exception('Invalid indexer type')
    elif (type1.IsMultidimArray):
        if (RobotRaconteur.UseNumPy):
            if (not isinstance(data,MultiDimArray)):
                if (not type1.VarLength):
                    VerifyMultiDimArrayLength_numpy(data,type1)
                PackToRRMultiDimArray_numpy(element,data,type1)
                return element
        if (not type1.VarLength):
            VerifyMultiDimArrayLength(data,type1)
        element.ElementType=RobotRaconteurPython.DataTypes_multidimarray_t
        iset=RobotRaconteurPython.vectorptr_messageelement()
        iset.append(PackMessageElement(data.DimCount, "int32 dimcount",node=node))
        iset.append(PackMessageElement(data.Dims, "int32[] dims",node=node))
        type1_r=RobotRaconteurPython.TypeDefinition()
        type1_r.FromString(type1.ToString())
        type1_r.Name="real"
        type1_r.IsMultidimArray=False
        type1_r.VarLength=True;
        iset.append(PackMessageElement(data.Real,type1_r,node=node))
        if (not data.Complex):
            element.DataCount=3
        else:
            type1_i=RobotRaconteurPython.TypeDefinition()
            type1_i.FromString(type1.ToString())
            type1_i.Name="imag"
            type1_i.IsMultidimArray=False
            iset.append(PackMessageElement(data.Imag,type1_i,node=node))
            element.DataCount=4
        element.SetData(RobotRaconteurPython.MessageElementMultiDimArray(iset))
        return element

    elif (type1.Type== RobotRaconteurPython.DataTypes_structure_t):
        typestr=data.rrstructtype
        (servicetype,structuretype)=SplitQualifiedName(typestr)
        typestr2=type1.TypeString
        if ('.' in typestr2):
            if (typestr!=typestr2): raise Exception("Data type error")
        else:
            if (structuretype!=typestr2): raise Exception("Data type error")

        element.ElementType=RobotRaconteurPython.DataTypes_structure_t
        element.ElementTypeName=typestr

        if (obj is None):
            sdef=node.GetServiceType(servicetype)
        else:
            sdef=node.GetPulledServiceType(obj,servicetype)
        structdef=FindStructureByName(sdef.Structures,structuretype)
        #structdef=[s for s in sdef.Structures if s.Name== structuretype][0]
        iset=RobotRaconteurPython.vectorptr_messageelement()
        for i in range(len(structdef.Members)):
            member=structdef.Members[i]
            el=PackMessageElement(eval("data.%s" % member.Name),member.Type,obj,node=node)
            el.ElementName=member.Name
            iset.append(el)
        element.DataCount=len(iset)
        element.SetData(RobotRaconteurPython.MessageElementStructure(typestr,iset))
        return element

    elif (type1.Type == RobotRaconteurPython.DataTypes_string_t):
        element.ElementType=RobotRaconteurPython.DataTypes_string_t

        element.SetData(PackToRRArray(data.encode('utf-8'),type1))
        element.DataCount=element.GetData().Length()
        return element
    elif (type1.Type>=RobotRaconteurPython.DataTypes_double_t and type1.Type <= RobotRaconteurPython.DataTypes_uint64_t):
        if (type1.Length!=0 and (type1.IsArray or  type1.IsMultidimArray)):
            if (type1.VarLength):
                if (len(data) > type1.Length): raise Exception("Array too large")
            else:
                if (len(data) != type1.Length): raise Exception("Array not correct length")
        element.ElementType=type1.Type
        if (not hasattr(data,'__len__')):
            element.SetData(PackToRRArray([data],type1))
        else:
            element.SetData(PackToRRArray(data,type1))
        element.DataCount=element.GetData().Length()
        return element
    else:
        raise Exception('Could not pack message element')



def UnpackMessageElement(element,type1=None,obj=None,node=None):
    if (node is None):
        node=RobotRaconteurPython.RobotRaconteurNode.s
    if (not type1 is None):
        if (isinstance(type1,str)):
            if (len(type1.split())==1): type1=type1+ " value"
            type2=RobotRaconteurPython.TypeDefinition()
            type2.FromString(type1)
            type1=type2
        if (type1.Type==RobotRaconteurPython.DataTypes_varvalue_t):
            if (not type1.IsMap and not type1.IsList):
                type1=None
                vardata=UnpackMessageElement(element,obj=obj,node=node)
                type1_2t=RobotRaconteurPython.TypeDefinition()
                if (element.ElementType >=RobotRaconteurPython.DataTypes_double_t and element.ElementType <= RobotRaconteurPython.DataTypes_uint64_t):
                    type1_2t.IsArray=True
                    type1_2t.Type=element.ElementType
                elif (element.ElementType==RobotRaconteurPython.DataTypes_string_t):
                    type1_2t.Type=element.ElementType
                elif (element.ElementType==RobotRaconteurPython.DataTypes_structure_t):
                    type1_2t.Type=element.ElementType
                    type1_2t.TypeString=element.ElementTypeName
                elif (element.ElementType==RobotRaconteurPython.DataTypes_list_t):
                    type1_2t.Type=RobotRaconteurPython.DataTypes_varvalue_t
                    type1_2t.IsList=True
                elif (element.ElementType==RobotRaconteurPython.DataTypes_vector_t):
                    type1_2t.Type=RobotRaconteurPython.DataTypes_varvalue_t
                    type1_2t.IsMap=True
                    type1_2t.KeyType=RobotRaconteurPython.DataTypes_int32_t
                elif (element.ElementType==RobotRaconteurPython.DataTypes_dictionary_t):
                    type1_2t.Type=RobotRaconteurPython.DataTypes_varvalue_t
                    type1_2t.IsMap=True
                    type1_2t.KeyType=RobotRaconteurPython.DataTypes_string_t
                elif (element.ElementType==RobotRaconteurPython.DataTypes_multidimarray_t):
                    type1_2t.IsArray=True
                    type1_2t.IsMultidimArray=True
                    type1_2t.Type=FindMessageElementByName(element.GetData().Elements,'real').ElementType
                    #type1_2t.Type=[e for e in element.GetData().Elements if e.ElementName=='real'][0].ElementType
                else:
                    raise Exception("Invalid data type")

                return RobotRaconteurVarValue(vardata,type1_2t.ToString())
            else:
                if (element.ElementType==RobotRaconteurPython.DataTypes_list_t):
                    ret=[]
                    for el in element.GetData().Elements:
                        ret[int(el.ElementName)]=UnpackMessageElement(el,"varvalue value",obj,node=node)
                    return ret
                if (element.ElementType==RobotRaconteurPython.DataTypes_vector_t):
                    ret={}
                    for el in element.GetData().Elements:
                        ret[int(el.ElementName)]=UnpackMessageElement(el,"varvalue value",obj,node=node)
                    return ret
                if (element.ElementType==RobotRaconteurPython.DataTypes_dictionary_t):
                    ret={}
                    for el in element.GetData().Elements:
                        ret[el.ElementName.decode('utf-8')]=UnpackMessageElement(el,"varvalue value",obj,node=node)
                    return ret
                raise Exception("Invalid map key type")


    if (element.ElementType==RobotRaconteurPython.DataTypes_void_t):
        return None
    elif(element.ElementType>=RobotRaconteurPython.DataTypes_double_t and element.ElementType <= RobotRaconteurPython.DataTypes_uint64_t):
        if (type1!=None):
            if (not type1.IsArray):
                return UnpackFromRRArray(element.GetData(),type1)[0]
        el=element.GetData()
        if (type1 is not None):
            if (type1.Length!=0 and (type1.IsArray or  type1.IsMultidimArray)):
                if (type1.VarLength):
                    if (el.Length() > type1.Length): raise Exception("Array too large")
                else:
                    if (el.Length() != type1.Length): raise Exception("Array not correct length")
        return UnpackFromRRArray(el,type1)
    elif(element.ElementType==RobotRaconteurPython.DataTypes_string_t):
        return UnpackFromRRArray(element.GetData(),type1).decode('utf-8')
    elif(element.ElementType==RobotRaconteurPython.DataTypes_structure_t):
        typestr=element.ElementTypeName

        (servicetype,structuretype)=SplitQualifiedName(typestr)
        if (obj is None):
            sdef=node.GetServiceType(servicetype)
        else:
            sdef=node.GetPulledServiceType(obj,servicetype)
        structdef=FindStructureByName(sdef.Structures,structuretype)
        #structdef=[s for s in sdef.Structures if s.Name== structuretype][0]

        struct=NewStructure(typestr,obj)
        for i in range(len(structdef.Members)):
            member=structdef.Members[i]
            el=FindMessageElementByName(element.GetData().Elements,member.Name)
            #el=[e for e in element.GetData().Elements if e.ElementName==member.Name][0]
            field=UnpackMessageElement(el,member.Type,obj,node=node) #@UnusedVariable
            exec("struct.%s=field" % member.Name)
        return struct
    elif (element.ElementType==RobotRaconteurPython.DataTypes_list_t):
        if (not type1 is None):
            if (not type1.IsList):
                raise Exception('Invalid data type')
            type2=RobotRaconteurPython.TypeDefinition()
            type2.FromString(type1.ToString())
            type2.IsList=False
            type2.KeyType=0
        else:
            type2=None

        ret=[]
        i=0
        for el in element.GetData().Elements:
            if (int(el.ElementName)!=i):
                raise Exception("List format error")
            ret.append(UnpackMessageElement(el,type2,obj,node=node))
            i+=1
        return ret
    elif (element.ElementType==RobotRaconteurPython.DataTypes_vector_t):
        if (not type1 is None):
            if (not type1.IsMap):
                raise Exception('Invalid data type')
            type2=RobotRaconteurPython.TypeDefinition()
            type2.FromString(type1.ToString())
            type2.IsMap=False
            type2.KeyType=0
        else:
            type2=None

        ret={}
        for el in element.GetData().Elements:
            ret[int(el.ElementName)]=UnpackMessageElement(el,type2,obj,node=node)
        return ret

    elif (element.ElementType==RobotRaconteurPython.DataTypes_dictionary_t):
        if (not type1 is None):
            if (not type1.IsMap):
                raise Exception('Invalid data type')
            type2=RobotRaconteurPython.TypeDefinition()
            type2.FromString(type1.ToString())
            type2.IsMap=False
            type2.KeyType=0
        else:
            type2=None

        ret={}
        for el in element.GetData().Elements:
            ret[el.ElementName.decode('utf-8')]=UnpackMessageElement(el,type2,obj,node=node)
        return ret
    elif (element.ElementType==RobotRaconteurPython.DataTypes_multidimarray_t):
        if (not type1 is None):
            if (not type1.IsMultidimArray):
                raise Exception('Invalid Data Type')
        if (RobotRaconteur.UseNumPy):

            m=UnpackFromRRMultiDimArray(element)
            if (not type1 is None):
                if (not type1.VarLength):
                    VerifyMultiDimArrayLength_numpy(m,type1)
            return m

        m=RobotRaconteurPython.MultiDimArray()
        m.Dims=UnpackMessageElement(FindMessageElementByName(element.GetData().Elements,'dims'),'int32[] dims',node=node)
        #m.Dims=UnpackMessageElement([e for e in element.GetData().Elements if e.ElementName=='dims'][0],'int32[] dims',node=node)
        m.DimCount=UnpackMessageElement(FindMessageElementByName(element.GetData().Elements,'dimcount'),'int32 dimcount',node=node)
        #m.DimCount=UnpackMessageElement([e for e in element.GetData().Elements if e.ElementName=='dimcount'][0],'int32 dimcount',node=node)
        if (len(m.Dims) !=m.DimCount): raise Exception('MultiDimArray mismatch')
        #type1_r=RobotRaconteurPython.TypeDefinition(type1)
        #type1_r.Name="real"
        #type1_r.IsMultiDimArray=False
        m.Real=UnpackMessageElement(FindMessageElementByName(element.GetData().Elements,'real'),node=node)
        #m.Real=UnpackMessageElement([e for e in element.GetData().Elements if e.ElementName=='real'][0],node=node)
        imag_search=[e for e in element.GetData().Elements if e.ElementName=='imag']
        if (len(imag_search)>0):
            #type1_i=RobotRaconteurPython.TypeDefinition(type1)
            #type1_i.Name="imag"
            #type1_i.IsMultiDimArray=False
            m.Imag=UnpackMessageElement(imag_search[0],node=node)
            m.Complex=True
        else:
            m.Complex=False
        if (type1 is not None):
            if (not type1.VarLength):
                VerifyMultiDimArrayLength(m,type1)
        return m
    else:
        raise Exception('Invalid data type')


def PackToRRArray(array,type1,destrrarray=None):

    if (array is None): return None
    if( not(type1.Type>=RobotRaconteurPython.DataTypes_double_t and type1.Type <= RobotRaconteurPython.DataTypes_string_t)):
        raise Exception('Invalid argument type')
    if (RobotRaconteur.UseNumPy):
        if (isinstance(array,numpy.ndarray)):
            if (NumPyDataTypeToRRTypeId(array.dtype)==type1.Type):
                return PackToRRArray_numpy(array,type1,destrrarray)

    packs='xdfbBhHlLqQcxxxxxxx'
    packs1=packs[type1.Type]
    if (packs1=='x'): raise Exception('Invalid argument type')
    if (destrrarray==None):
        out=RobotRaconteurPython.AllocateRRArrayByType(type1.Type,len(array))
    else:
        if (destrrarray.GetTypeID() != type1.Type): raise Exception("Incorrect destrrarray data type")
        if (destrrarray.Length() !=len(array)): raise Exception("Incorrect destrrarray length")
        out=destrrarray

    c_out=(ctypes.c_ubyte*(out.Length()*out.ElementSize())).from_address(out.void_ptr())

    struct.pack_into("=" + str(len(array)) + packs1,c_out,0,*array)
    return out

def UnpackFromRRArray(rrarray,type1=None):

    if (rrarray is None): return None
    typeid=rrarray.GetTypeID()
    if (not type1 is None):
        if (typeid != type1.Type): raise RRE.DataTypeMismatchException("Data type mismatch")
    if( not(typeid>=RobotRaconteurPython.DataTypes_double_t and typeid <= RobotRaconteurPython.DataTypes_string_t)):
        raise Exception('Invalid argument type')
    if (RobotRaconteur.UseNumPy):
        if(typeid>=RobotRaconteurPython.DataTypes_double_t and typeid <= RobotRaconteurPython.DataTypes_uint64_t):
            return UnpackFromRRArray_numpy(rrarray,type1)
    packs='xdfbBhHlLqQsxxxxxxx'
    packs1=packs[typeid]
    if (packs1=='x'): raise Exception('Invalid argument type')
    c_rrarray=(ctypes.c_ubyte*(rrarray.Length()*rrarray.ElementSize())).from_address(rrarray.void_ptr())

    value= struct.unpack_from("=" + str(rrarray.Length()) + packs1,c_rrarray,0)
    if (packs1=='s'):
        return value[0]
    return value


def NewStructure(StructType,obj=None,node=None):
    if (node is None):
        node=RobotRaconteurPython.RobotRaconteurNode.s
    (servicetype,structuretype)=SplitQualifiedName(StructType)
    if (obj is None):
        sdef=node.GetServiceType(servicetype)
    else:
        sdef=node.GetPulledServiceType(obj,servicetype)
    structdef=FindStructureByName(sdef.Structures,structuretype)
    #structdef=[s for s in sdef.Structures  if s.Name==structuretype][0]

    struct=RobotRaconteurStructure()
    for member in structdef.Members:
        exec("struct.%s=None" % member.Name)
    struct.rrstructtype=sdef.Name + "." + structdef.Name
    return struct

def InitStub(stub):
    odef=stub.RR_objecttype
    mdict={}

    for i in range(len(odef.Members)):
        m=odef.Members[i]
        if (isinstance(m,RobotRaconteurPython.PropertyDefinition)):
            def inner_prop(m1):
                fget=lambda  self : stub_getproperty(stub,m1.Name,m1)
                fset=lambda self, value : stub_setproperty(stub,m1.Name,m1,value)
                return property(fget,fset)
            p1=inner_prop(m)

            mdict[m.Name]=p1

            def inner_async_prop(m1):
                fget=lambda  self,handler,timeout=RobotRaconteurPython.RR_TIMEOUT_INFINITE : stub_async_getproperty(stub,m1.Name,m1,handler,timeout)
                fset=lambda self, value,handler,timeout=RobotRaconteurPython.RR_TIMEOUT_INFINITE : stub_async_setproperty(stub,m1.Name,m1,value,handler,timeout)
                return fget, fset
            p1_async=inner_async_prop(m)

            mdict['async_get_' + m.Name]=p1_async[0]
            mdict['async_set_' + m.Name]=p1_async[1]


        if (isinstance(m,RobotRaconteurPython.FunctionDefinition)):
            def inner_func(m1):
                if (m1.ReturnType.Type==RobotRaconteurPython.DataTypes_void_t):
                    f=lambda self,*args : stub_functioncallvoid(stub,m1.Name,m1,*args)
                else:
                    f=lambda self,*args : stub_functioncall(stub,m1.Name,m1,*args)
                return f
            f1=inner_func(m)
            mdict[m.Name]=f1

            def inner_async_func(m1):
                if (m1.ReturnType.Type==RobotRaconteurPython.DataTypes_void_t):
                    f=lambda self,*args : stub_async_functioncallvoid(stub,m1.Name,m1,*args)
                else:
                    f=lambda self,*args : stub_async_functioncall(stub,m1.Name,m1,*args)
                return f

            f1_async=inner_async_func(m)
            mdict['async_' + m.Name]=f1_async

        if (isinstance(m,RobotRaconteurPython.ObjRefDefinition)):
            def inner_objref(m1):
                if(m1.IsMap or m1.IsArray):
                    f=lambda self,index : stub_objref(stub,m1.Name,index)
                else:
                    f=lambda self : stub_objref(stub,m1.Name)
                return f
            f1=inner_objref(m)
            mdict['get_%s' % m.Name]=f1

            def inner_async_objref(m1):
                if(m1.IsMap or m1.IsArray):
                    f=lambda self,index,handler,timeout=RobotRaconteurPython.RR_TIMEOUT_INFINITE : stub_async_objref(stub,m1.Name,index,handler,timeout)
                else:
                    f=lambda self,handler,timeout=RobotRaconteurPython.RR_TIMEOUT_INFINITE : stub_async_objref(stub,m1.Name,None,handler,timeout)
                return f
            f1=inner_async_objref(m)
            mdict['async_get_%s' % m.Name]=f1

        if (isinstance(m,RobotRaconteurPython.PipeDefinition)):
            def inner_pipe(m1):
                innerp=stub.GetPipe(m1.Name)
                outerp=Pipe(innerp)
                fget=lambda self : outerp
                return property(fget)
            p2=inner_pipe(m)
            mdict[m.Name]=p2

        if (isinstance(m,RobotRaconteurPython.WireDefinition)):
            def inner_wire(m1):
                innerw=stub.GetWire(m1.Name)
                outerw=Wire(innerw)
                fget=lambda self : outerw
                return property(fget)
            w=inner_wire(m)
            mdict[m.Name]=w

        if (isinstance(m,RobotRaconteurPython.MemoryDefinition)):
            def inner_memory(m1):
                if (not m.Type.IsMultidimArray):
                    outerm=ArrayMemoryClient(stub.GetArrayMemory(m1.Name))
                else:
                    outerm=MultiDimArrayMemoryClient(stub.GetMultiDimArrayMemory(m1.Name))
                fget=lambda self: outerm
                return property(fget)
            mem=inner_memory(m)
            mdict[m.Name]=mem


    outerstub_type=type(str(odef.Name),(ServiceStub,),mdict)
    outerstub=outerstub_type()

    for i in range(len(odef.Members)):
        m=odef.Members[i]

        if (isinstance(m,RobotRaconteurPython.PipeDefinition)):
            p=getattr(outerstub,m.Name)
            p._obj=outerstub

        if (isinstance(m,RobotRaconteurPython.WireDefinition)):
            w=getattr(outerstub,m.Name)
            w._obj=outerstub

    director=WrappedServiceStubDirectorPython(outerstub,stub)
    stub.SetRRDirector(director,0)
    director.__disown__()

    stub.SetPyStub(outerstub)

    for i in range(len(odef.Members)):
        m=odef.Members[i]

        if (isinstance(m,RobotRaconteurPython.EventDefinition)):
            setattr(outerstub,m.Name,EventHook())
        if (isinstance(m,RobotRaconteurPython.CallbackDefinition)):
            setattr(outerstub,m.Name, CallbackClient())
    outerstub.rrinnerstub=stub;
    outerstub.rrlock=threading.RLock()
    return outerstub


def stub_getproperty(stub,name,type1):
    return UnpackMessageElement(stub.PropertyGet(name),type1.Type,stub,stub.RRGetNode())

def stub_setproperty(stub,name,type1,value):
    pvalue=PackMessageElement(value,type1.Type,stub,stub.RRGetNode())
    stub.PropertySet(name,pvalue)

def stub_functioncall(stub,name,type1,*args):
    m=RobotRaconteurPython.vectorptr_messageelement()
    i=0
    for p in type1.Parameters:
        a=PackMessageElement(args[i],p,stub,stub.RRGetNode())
        m.append(a)
        i+=1
    ret=stub.FunctionCall(name,m)
    return UnpackMessageElement(ret,type1.ReturnType,stub,stub.RRGetNode())

def stub_functioncallvoid(stub,name,type1,*args):
    m=RobotRaconteurPython.vectorptr_messageelement()
    i=0
    for p in type1.Parameters:
        a=PackMessageElement(args[i],p,stub)
        m.append(a)
        i+=1
    stub.FunctionCall(name,m)

class AsyncTransactionDirectorImpl(RobotRaconteurPython.AsyncHandlerDirector):
    def __init__(self,handler,isvoid,Type,node):
        super(AsyncTransactionDirectorImpl,self).__init__()
        self._handler=handler
        self._isvoid=isvoid
        self._Type=Type
        self._node=node

    def handler(self,m,error_code,errorname,errormessage):

        if (self._isvoid):
            if (error_code!=0):
                err=RobotRaconteurPythonError.RobotRaconteurExceptionUtil.ErrorCodeToException(error_code,errorname,errormessage)
                self._handler(err)
                return
            else:
                self._handler(None)
        else:
            if (error_code!=0):
                err=RobotRaconteurPythonError.RobotRaconteurExceptionUtil.ErrorCodeToException(error_code,errorname,errormessage)
                self._handler(None,err)
                return
            else:
                if (m==0):
                    self._handler(None,None)
                    return
                value2=RobotRaconteurPython.MessageElementDataUtil.VoidToMessageElement(m)
                try:
                    a=UnpackMessageElement(value2,self._Type,self._node)
                except Exception as err:
                    self._handler(None,err)
                    return
                self._handler(a,None)
                return


def stub_async_getproperty(stub,name,type1,handler,timeout=-1):
    return async_call(stub.async_PropertyGet,(name,adjust_timeout(timeout)),AsyncTransactionDirectorImpl,handler,directorargs=(False,type1.Type,stub.RRGetNode()))

def stub_async_setproperty(stub,name,type1,value,handler,timeout=-1):
    pvalue=PackMessageElement(value,type1.Type,stub)
    return async_call(stub.async_PropertySet,(name,pvalue,adjust_timeout(timeout)),AsyncTransactionDirectorImpl,handler,directorargs=(True,type1.Type,stub.RRGetNode()))


def stub_async_functioncall(stub,name,type1,*args):
    m=RobotRaconteurPython.vectorptr_messageelement()
    i=0
    for p in type1.Parameters:
        a=PackMessageElement(args[i],p,stub)
        m.append(a)
        i+=1
    handler=args[i]
    if (len(args) > i+1):
        timeout=args[i+1]
    else:
        timeout=RobotRaconteurPython.RR_TIMEOUT_INFINITE
    return async_call(stub.async_FunctionCall,(name,m,adjust_timeout(timeout)),AsyncTransactionDirectorImpl,handler,directorargs=(False,type1.ReturnType,stub.RRGetNode()))

def stub_async_functioncallvoid(stub,name,type1,*args):
    m=RobotRaconteurPython.vectorptr_messageelement()
    i=0
    for p in type1.Parameters:
        a=PackMessageElement(args[i],p,stub)
        m.append(a)
        i+=1
    handler=args[i]
    if (len(args) > i+1):
        timeout=args[i+1]
    else:
        timeout=-1

    return async_call(stub.async_FunctionCall,(name,m,adjust_timeout(timeout)),AsyncTransactionDirectorImpl,handler,directorargs=(True,type1.ReturnType,stub.RRGetNode()))

_stub_objref_lock=threading.Lock()

def stub_objref(stub,name,index=None):
    if (index is None):
        s=stub.FindObjRef(name)
        with _stub_objref_lock:
            s2=s.GetPyStub()
            if (s2 is not None): return s2
            return InitStub(s)

        return
    else:
        s=stub.FindObjRef(name,str(index))
        with _stub_objref_lock:
            s2=s.GetPyStub()
            if (s2 is not None): return s2
            return InitStub(s)

def stub_async_objref(stub,name,index,handler,timeout=-1):
    if (index is None):
        return async_call(stub.async_FindObjRef,(name,adjust_timeout(timeout)),AsyncStubReturnDirector,handler)
    else:
        return async_call(stub.async_FindObjRef,(name,str(ind),adjust_timeout(timeout)),AsyncStubReturnDirector,handler)

class WrappedServiceStubDirectorPython(RobotRaconteurPython.WrappedServiceStubDirector):
    def __init__(self,stub,innerstub):
        self.stub=stub;
        self.innerstub=innerstub
        super(WrappedServiceStubDirectorPython, self).__init__()

    def DispatchEvent(self, name, args1):

        type1=FindMemberByName(self.innerstub.RR_objecttype.Members,name)
        #type1=[e for e in self.innerstub.RR_objecttype.Members if e.Name == name][0]
        args=[]
        args2=RobotRaconteurPython.MessageElementDataUtil.VoidToMessageElementVector(args1)
        type2=RobotRaconteurPython.MemberDefinitionUtil.ToEvent(type1)
        for p in type2.Parameters:
            m=FindMessageElementByName(args2,p.Name)
            #m=[mm for mm in args2 if mm.ElementName==p.Name][0]
            a=UnpackMessageElement(m,p,self.stub,node=self.innerstub.RRGetNode())
            args.append(a)
        exec('self.stub.%s.fire(*args)' % name)



    def CallbackCall(self, name, args1):

        type1=FindMemberByName(self.innerstub.RR_objecttype.Members,name)
        #type1=[e for e in self.innerstub.RR_objecttype.Members if e.Name == name][0]
        args=[]
        args2=RobotRaconteurPython.MessageElementDataUtil.VoidToMessageElementVector(args1)

        type2=RobotRaconteurPython.MemberDefinitionUtil.ToCallback(type1)
        for p in type2.Parameters:
            m=FindMessageElementByName(args2,p.Name)
            #m=[mm for mm in args2 if mm.ElementName==p.Name][0]
            a=UnpackMessageElement(m,p,self.stub,self.innerstub.RRGetNode())
            args.append(a)
        exec('ret=self.stub.%s.Function(*args)' % name)

        if (ret is None):
            m=RobotRaconteurPython.MessageElement()
            m.ElementName="return"
            m.ElementType=RobotRaconteurPython.DataTypes_void_t
            return RobotRaconteurPython.MessageElementDataUtil.MessageElementToVoid(m)
        return RobotRaconteurPython.MessageElementDataUtil.MessageElementToVoid(PackMessageElement(ret,type2.ReturnType,self.stub,self.innerstub.RRGetNode()))


class ServiceStub(object):
    pass

class CallbackClient(object):
    def __init__(self):
        self.Function=None

class PipeAsyncCloseHandler(RobotRaconteurPython.AsyncHandlerDirector):
    def __init__(self,handler):
        super(PipeAsyncCloseHandler,self).__init__()
        self._handler=handler

    def handler(self, innerendpoint, error_code,errorname,errormessage):
        if (error_code!=0):
            err=RobotRaconteurPythonError.RobotRaconteurExceptionUtil.ErrorCodeToException(error_code,errorname,errormessage)
            self._handler(err)
            return
        self._handler(None)

class PipeAsyncSendHandler(RobotRaconteurPython.AsyncHandlerDirector):
    def __init__(self,handler):
        super(PipeAsyncSendHandler,self).__init__()
        self._handler=handler

    def handler(self, id, error_code,errorname,errormessage):
        if (error_code!=0):
            err=RobotRaconteurPythonError.RobotRaconteurExceptionUtil.ErrorCodeToException(error_code,errorname,errormessage)
            self._handler(None,err)
            return

        self._handler(RobotRaconteurPython.WrappedPipeEndpointUtil.VoidToUInt32(id), None)

class PipeEndpoint(object):
    def __init__(self,innerpipe, type, obj=None):
        self.__innerpipe=innerpipe
        self.__type=type
        self.PipeEndpointClosedCallback=None
        self.PacketReceivedEvent=EventHook()
        self.PacketAckReceivedEvent=EventHook()
        self.__obj=obj

    @property
    def Index(self):
        return self.__innerpipe.GetIndex()

    @property
    def Endpoint(self):
        return self.__innerpipe.GetEndpoint()

    @property
    def Available(self):
        return self.__innerpipe.Available()

    @property
    def IsUnreliable(self):
        return self.__innerpipe.IsUnreliable()

    @property
    def RequestPacketAck(self):
        return self.__innerpipe.GetRequestPacketAck()

    @RequestPacketAck.setter
    def RequestPacketAck(self,value):
        self.__innerpipe.SetRequestPacketAck(value)

    @property
    def IgnoreReceived(self):
        return self.__innerpipe.GetIgnoreReceived()

    @IgnoreReceived.setter
    def IgnoreReceived(self,value):
        self.__innerpipe.SetIgnoreReceived(value)

    def Close(self):
        return self.__innerpipe.Close()

    def AsyncClose(self,handler,timeout=2):
        return async_call(self.__innerpipe.AsyncClose,(adjust_timeout(timeout),),PipeAsyncCloseHandler,handler)

    def SendPacket(self,packet):
        m=PackMessageElement(packet,self.__type,self.__obj,self.__innerpipe.GetNode())
        return self.__innerpipe.SendPacket(m)

    def AsyncSendPacket(self, packet, handler):
        m=PackMessageElement(packet,self.__type,self.__obj,self.__innerpipe.GetNode())
        return async_call(self.__innerpipe.AsyncSendPacket,(m,),PipeAsyncSendHandler,handler)

    def ReceivePacket(self):
        m=self.__innerpipe.ReceivePacket()
        return UnpackMessageElement(m,self.__type,self.__obj,self.__innerpipe.GetNode())

    def PeekNextPacket(self):
        m=self.__innerpipe.PeekNextPacket()
        return UnpackMessageElement(m,self.__type,self.__obj,self.__innerpipe.GetNode())


class PipeEndpointDirector(RobotRaconteurPython.WrappedPipeEndpointDirector):
    def __init__(self,endpoint):
        self.__endpoint=endpoint
        super(PipeEndpointDirector, self).__init__()

    def PipeEndpointClosedCallback(self):

        if (not self.__endpoint.PipeEndpointClosedCallback is None):
            self.__endpoint.PipeEndpointClosedCallback(self.__endpoint)


    def PacketReceivedEvent(self):

        self.__endpoint.PacketReceivedEvent.fire(self.__endpoint)


    def PacketAckReceivedEvent(self,packetnum):

        self.__endpoint.PacketAckReceivedEvent.fire(self.__endpoint,packetnum)


class PipeAsyncConnectHandler(RobotRaconteurPython.AsyncHandlerDirector):
    def __init__(self,handler,innerpipe,obj):
        super(PipeAsyncConnectHandler,self).__init__()
        self._handler=handler
        self.__innerpipe=innerpipe
        self.__obj=obj

    def handler(self, innerendpoint1, error_code,errorname,errormessage):
        if (error_code!=0):
            err=RobotRaconteurPythonError.RobotRaconteurExceptionUtil.ErrorCodeToException(error_code,errorname,errormessage)
            self._handler(None,err)
            return
        try:
            innerendpoint=RobotRaconteurPython.WrappedPipeEndpointUtil.VoidToWrappedPipeEndpoint(innerendpoint1)
            outerendpoint=PipeEndpoint(innerendpoint,self.__innerpipe.Type,self.__obj)
            director=PipeEndpointDirector(outerendpoint)
            innerendpoint.SetRRDirector(director,0)
            director.__disown__()
        except Exception as err2:
            self._handler(None, err2)
            return
        self._handler(outerendpoint, None)

class Pipe(object):
    def __init__(self,innerpipe,obj=None):
        self.__innerpipe=innerpipe
        self.PipeConnectCallback=None
        self._obj=obj

    def Connect(self,index):
        innerendpoint=self.__innerpipe.Connect(index)
        outerendpoint=PipeEndpoint(innerendpoint,self.__innerpipe.Type,self._obj)
        director=PipeEndpointDirector(outerendpoint)
        innerendpoint.SetRRDirector(director,0)
        director.__disown__()
        return outerendpoint

    def AsyncConnect(self,*args):
        if (isinstance(args[0], (int, long, float))):
            index=args[0]
            handler=args[1]
            if (len(args)>=3):
                timeout=args[2]
            else:
                timeout=RobotRaconteurPython.RR_TIMEOUT_INFINITE
        else:
            index=-1
            handler=args[0]
            if (len(args)>=2):
                timeout=args[1]
            else:
                timeout=RobotRaconteurPython.RR_TIMEOUT_INFINITE

        return async_call(self.__innerpipe.AsyncConnect,(index,adjust_timeout(timeout)),PipeAsyncConnectHandler,handler,directorargs=(self.__innerpipe,self._obj))

    @property
    def MemberName(self):
        return self.__innerpipe.GetMemberName()
        pass

class WrappedPipeServerDirectorPython(RobotRaconteurPython.WrappedPipeServerDirector):
    def __init__(self,pipe,type):
        self.pipe=pipe
        self.type=type
        super(WrappedPipeServerDirectorPython,self).__init__()

    def PipeConnectCallback(self,pipeendpoint):

        innerendpoint=RobotRaconteurPython.WrappedPipeEndpointUtil.VoidToWrappedPipeEndpoint(pipeendpoint)
        outerendpoint=PipeEndpoint(innerendpoint,self.type)
        director=PipeEndpointDirector(outerendpoint)
        innerendpoint.SetRRDirector(director,0)
        director.__disown__()
        self.pipe.PipeConnectCallback(outerendpoint)



class WireAsyncCloseHandler(RobotRaconteurPython.AsyncHandlerDirector):
    def __init__(self,handler):
        super(WireAsyncCloseHandler,self).__init__()
        self._handler=handler

    def handler(self, innerendpoint, error_code,errorname,errormessage):
        if (error_code!=0):
            err=RobotRaconteurPythonError.RobotRaconteurExceptionUtil.ErrorCodeToException(error_code,errorname,errormessage)
            self._handler(err)
            return
        self._handler(None)

class WireConnection(object):
    def __init__(self,innerwire, type, obj=None):
        self.__innerwire=innerwire
        self.__type=type
        self.WireConnectionClosedCallback=None
        self.WireValueChanged=EventHook()
        self.__obj=obj

    @property
    def Endpoint(self):
        return self.__innerwire.GetEndpoint()

    def Close(self):
        return self.__innerwire.Close()

    def AsyncClose(self,handler,timeout=2):
        return async_call(self.__innerwire.AsyncClose,(adjust_timeout(timeout),),WireAsyncCloseHandler,handler)

    @property
    def InValue(self):
        m=self.__innerwire.GetInValue()
        return UnpackMessageElement(m,self.__type,self.__obj,self.__innerwire.GetNode())

    @property
    def OutValue(self):
        m=self.__innerwire.GetOutValue()
        return UnpackMessageElement(m,self.__type,self.__obj,self.__innerwire.GetNode())

    @OutValue.setter
    def OutValue(self,value):
        m=PackMessageElement(value,self.__type,self.__obj,self.__innerwire.GetNode())
        return self.__innerwire.SetOutValue(m)

    @property
    def LastValueReceivedTime(self):
        return self.__innerwire.GetLastValueReceivedTime()

    @property
    def LastValueSentTime(self):
        return self.__innerwire.GetLastValueSentTime()

    @property
    def InValueValid(self):
        return self.__innerwire.GetInValueValid()

    @property
    def OutValueValid(self):
        return self.__innerwire.GetOutValueValid()
		
    @property
    def IgnoreInValue(self):
        return self.__innerwire.GetIgnoreInValue()

    @IgnoreInValue.setter
    def IgnoreInValue(self,value):
        self.__innerwire.SetIgnoreInValue(value)

class WireConnectionDirector(RobotRaconteurPython.WrappedWireConnectionDirector):

    def __init__(self,endpoint,type,obj=None,innerep=None):
        self.__endpoint=endpoint
        self.__type=type
        self.__obj=obj
        self.__innerep=innerep
        super(WireConnectionDirector, self).__init__()

    def WireValueChanged(self,value,time):

        value2=UnpackMessageElement(RobotRaconteurPython.MessageElementDataUtil.VoidToMessageElement(value),self.__type,self.__obj,self.__innerep.GetNode())
        self.__endpoint.WireValueChanged.fire(self.__endpoint,value2,time)


    def WireConnectionClosedCallback(self):

        if (not self.__endpoint.WireConnectionClosedCallback is None):
            self.__endpoint.WireConnectionClosedCallback(self.__endpoint)


class WireAsyncConnectHandler(RobotRaconteurPython.AsyncHandlerDirector):
    def __init__(self,handler,innerpipe,obj):
        super(WireAsyncConnectHandler,self).__init__()
        self._handler=handler
        self.__innerpipe=innerpipe
        self.__obj=obj

    def handler(self, innerendpoint1, error_code,errorname,errormessage):
        if (error_code!=0):
            err=RobotRaconteurPythonError.RobotRaconteurExceptionUtil.ErrorCodeToException(error_code,errorname,errormessage)
            self._handler(None,err)
            return
        try:
            innerendpoint=RobotRaconteurPython.WrappedWireConnectionUtil.VoidToWrappedWireConnection(innerendpoint1)
            outerendpoint=WireConnection(innerendpoint,self.__innerpipe.Type,self.__obj)
            director=WireConnectionDirector(outerendpoint,self.__innerpipe.Type,self.__obj,innerendpoint)
            innerendpoint.SetRRDirector(director,0)
            director.__disown__()
        except Exception as err2:
            self._handler(None, err2)
            return
        self._handler(outerendpoint, None)

class Wire(object):
    def __init__(self,innerpipe,obj=None):
        self.__innerpipe=innerpipe
        self.WireConnectCallback=None
        self._obj=obj

    def Connect(self):
        innerendpoint=self.__innerpipe.Connect()
        outerendpoint=WireConnection(innerendpoint,self.__innerpipe.Type,self._obj)
        director=WireConnectionDirector(outerendpoint,self.__innerpipe.Type,self._obj,innerendpoint)
        innerendpoint.SetRRDirector(director,0)
        director.__disown__()
        return outerendpoint

    def AsyncConnect(self,handler,timeout=RobotRaconteurPython.RR_TIMEOUT_INFINITE):

        return async_call(self.__innerpipe.AsyncConnect,(adjust_timeout(timeout),),WireAsyncConnectHandler,handler,directorargs=(self.__innerpipe,self._obj))

    @property
    def MemberName(self):
        return self.__innerpipe.GetMemberName()

class WrappedWireServerDirectorPython(RobotRaconteurPython.WrappedWireServerDirector):
    def __init__(self,wire,type):
        self.wire=wire
        self.type=type
        super(WrappedWireServerDirectorPython,self).__init__()

    def WireConnectCallback(self,wireconnection):

        innerendpoint=RobotRaconteurPython.WrappedWireConnectionUtil.VoidToWrappedWireConnection(wireconnection)
        outerendpoint=WireConnection(innerendpoint,self.type)
        director=WireConnectionDirector(outerendpoint,self.type,innerep=innerendpoint)
        innerendpoint.SetRRDirector(director,0)
        director.__disown__()
        self.wire.WireConnectCallback(outerendpoint)



class ArrayMemoryClient(object):
    def __init__(self,innermemory):
        self.__innermemory=innermemory

    @property
    def Length(self):
        return self.__innermemory.Length()

    def Read(self, memorypos, buffer, bufferpos, count):
        dat=RobotRaconteurPython.WrappedArrayMemoryClientUtil.Read(self.__innermemory, memorypos, count)
        t=RobotRaconteurPython.TypeDefinition()
        t.Type=self.__innermemory.ElementTypeID()
        buffer[bufferpos:(bufferpos+count)]=UnpackFromRRArray(dat,t)

    def Write(self,memorypos, buffer, bufferpos, count):
        t=RobotRaconteurPython.TypeDefinition()
        t.Type=self.__innermemory.ElementTypeID()
        dat=PackToRRArray(buffer[bufferpos:(bufferpos+count)],t)
        RobotRaconteurPython.WrappedArrayMemoryClientUtil.Write(self.__innermemory, memorypos,dat,0,count)

class MultiDimArrayMemoryClient(object):
    def __init__(self,innermemory):
        self.__innermemory=innermemory

    @property
    def DimCount(self):
        return self.__innermemory.DimCount()

    @property
    def Dimensions(self):
        return list(self.__innermemory.Dimensions())

    @property
    def Complex(self):
        return self.__innermemory.Complex()

    def Read(self, memorypos, buffer, bufferpos, count):

        dat=RobotRaconteurPython.WrappedMultiDimArrayMemoryClientUtil.Read(self.__innermemory,memorypos,count)
        tdims=RobotRaconteurPython.TypeDefinition()
        tdims.Type=RobotRaconteurPython.DataTypes_int32_t
        dims=UnpackFromRRArray(dat.Dims,tdims)

        t=RobotRaconteurPython.TypeDefinition()
        t.Type=self.__innermemory.ElementTypeID()
        real=UnpackFromRRArray(dat.Real,t)
        imag=UnpackFromRRArray(dat.Imag,t)
        if (not RobotRaconteur.UseNumPy):
            dat2=MultiDimArray(dims,real,imag)

            buffer.AssignSubArray(bufferpos,dat2,[0]*len(count),count)
        else:
            memind=", ".join([(str(memorypos[i]) + ":" + str(memorypos[i]+count[i])) for i in range(len(count))])
            bufind=", ".join([(str(bufferpos[i]) + ":" + str(bufferpos[i]+count[i])) for i in range(len(count))])
            if (type(buffer) is list or type(buffer) is set or type(buffer) is tuple):
                realb=buffer[0]
                imagb=buffer[1]
                realm=real.reshape(dims,order="F")
                imagm=imag.reshape(dims,order="F")
                exec("realb[%s]=realm" % (bufind))
                exec("imagb[%s]=imagm" % (bufind))
            else:
                if (imag is None):
                    buffer2=real.reshape(dims,order="F")
                else:
                    buffer2=real.reshape(dims,order="F") + 1j*imag.reshape(dims)
                exec("buffer[%s]=(buffer2)" % (bufind))


    def Write(self, memorypos, buffer, bufferpos, count):

        tdims=RobotRaconteurPython.TypeDefinition()
        tdims.Type=RobotRaconteurPython.DataTypes_int32_t

        t=RobotRaconteurPython.TypeDefinition()
        t.Type=self.__innermemory.ElementTypeID()
        elementcount=reduce(operator.mul,count,1)
        dims=count
        if (not RobotRaconteur.UseNumPy):

            real=[0]*elementcount
            imag=None
            if (buffer.Complex):
                imag=[0]*elementcount

            writedat1=MultiDimArray(dims,real,imag)
            writedat1.AssignSubArray([0]*len(count),buffer,bufferpos,count)
        else:
            memind=", ".join([(str(memorypos[i]) + ":" + str(memorypos[i]+count[i])) for i in range(len(count))])
            bufind=", ".join([(str(bufferpos[i]) + ":" + str(bufferpos[i]+count[i])) for i in range(len(count))])
            if (type(buffer) is list or type(buffer) is set or type(buffer) is tuple):
                exec("real=(buffer[0])[%s].flatten(order=\"F\" )" % bufind)
                exec("imag=(buffer[1])[%s].flatten(order=\"F\" )" % bufind)
            else:
                if (buffer.dtype==numpy.complex64 or buffer.dtype==numpy.complex128):
                    exec("real=buffer[%s].real.flatten(order=\"F\")" % bufind)
                    exec("imag=buffer[%s].imag.flatten(order=\"F\")" % bufind)
                else:
                    exec("real=buffer[%s].real.flatten(order=\"F\")" % bufind)
                    imag=None

        dims2=PackToRRArray(count,tdims)
        real2=PackToRRArray(real,t)
        imag2=PackToRRArray(imag,t)

        writedat2=RobotRaconteurPython.RRMultiDimArrayUntyped()
        writedat2.DimCount=len(dims)
        writedat2.Dims=dims2
        writedat2.Complex=False
        writedat2.Real=real2
        if (not imag is None):
            writedat2.Complex=True
            writedat2.Imag=imag2

        RobotRaconteurPython.WrappedMultiDimArrayMemoryClientUtil.Write(self.__innermemory,memorypos,writedat2,[0]*len(count),count)

class ServiceInfo2(object):
    def __init__(self,info):
        self.Name=info.Name
        self.RootObjectType=info.RootObjectType
        self.RootObjectImplements=list(info.RootObjectImplements)
        self.ConnectionURL=list(info.ConnectionURL)
        self.NodeID=RobotRaconteurPython.NodeID(str(info.NodeID))
        self.NodeName=info.NodeName
        self.Attributes=UnpackMessageElement(info.Attributes,"varvalue{string} value")

class NodeInfo2(object):
    def __init__(self,info):
        self.NodeID=RobotRaconteurPython.NodeID(str(info.NodeID))
        self.NodeName=info.NodeName
        self.ConnectionURL=list(info.ConnectionURL)

class WrappedServiceSkelDirectorPython(RobotRaconteurPython.WrappedServiceSkelDirector):
    def __init__(self,obj):
        self.obj=obj
        super(WrappedServiceSkelDirectorPython,self).__init__()

    def Init(self,skel):

        skel2=RobotRaconteurPython.WrappedServiceUtil.VoidToWrappedServiceSkel(skel)
        self.skel=skel2
        odef=skel2.Type
        for i in range(len(odef.Members)):
            m=odef.Members[i]
            if (isinstance(m,RobotRaconteurPython.EventDefinition)):
                def inner_event(m1):

                    f=lambda *args : skel_dispatchevent(skel2,m1.Name,m1,*args)
                    return f
                f1=inner_event(m)
                execvars={"obj" : self.obj, "f1" : f1}
                exec("obj.%s+=f1" % m.Name) in execvars
            if (isinstance(m,RobotRaconteurPython.CallbackDefinition)):
                def inner_callback(m1):
                    if (m1.ReturnType.Type==RobotRaconteurPython.DataTypes_void_t):
                        f=lambda endpoint, *args : skel_callbackcallvoid(skel2,m1.Name,m1,endpoint,*args)
                    else:
                        f=lambda endpoint, *args : skel_callbackcall(skel2,m1.Name,m1,endpoint,*args)
                    return f
                f1=inner_callback(m)
                cs=CallbackServer(f1)
                execvars={"obj" : self.obj, "cs" : cs}
                exec ("obj.%s=cs" % m.Name) in execvars
            if (isinstance(m,RobotRaconteurPython.PipeDefinition)):
                p=skel2.GetPipe(m.Name)
                outerp=Pipe(p)
                wrappedp=WrappedPipeServerDirectorPython(outerp,p.Type)
                p.SetRRDirector(wrappedp,0)
                wrappedp.__disown__()
                execvars={"obj" : self.obj, "outerp" : outerp}
                exec("obj.%s=outerp" % m.Name) in execvars
            if (isinstance(m,RobotRaconteurPython.WireDefinition)):
                w=skel2.GetWire(m.Name)
                outerw=Wire(w)
                wrappedw=WrappedWireServerDirectorPython(outerw,w.Type)
                w.SetRRDirector(wrappedw,0)
                wrappedw.__disown__()
                execvars={"obj" : self.obj, "outerw" : outerw}
                exec("obj.%s=outerw" % m.Name) in execvars



    def CallGetProperty(self, name):

        type1=FindMemberByName(self.skel.Type.Members,name)
        #type1=[e for e in self.skel.Type.Members if e.Name == name][0]
        type2=RobotRaconteurPython.MemberDefinitionUtil.ToProperty(type1)
        exec('ret=self.obj.%s' % name)

        if (ret is None):
            m=RobotRaconteurPython.MessageElement()
            m.ElementName="value"
            m.ElementType=RobotRaconteurPython.DataTypes_void_t
            return RobotRaconteurPython.MessageElementDataUtil.MessageElementToVoid(m)
        return RobotRaconteurPython.MessageElementDataUtil.MessageElementToVoid(PackMessageElement(ret,type2.Type,node=self.skel.RRGetNode()))


    def CallSetProperty(self, name, value):

        type1=FindMemberByName(self.skel.Type.Members,name)
        #type1=[e for e in self.skel.Type.Members if e.Name == name][0]
        type2=RobotRaconteurPython.MemberDefinitionUtil.ToProperty(type1)
        value2=RobotRaconteurPython.MessageElementDataUtil.VoidToMessageElement(value)
        a=UnpackMessageElement(value2,type2.Type,node=self.skel.RRGetNode())
        exec('self.obj.%s=a' % name)


    def CallFunction(self, name, args1):

        type1=FindMemberByName(self.skel.Type.Members,name)
        #type1=[e for e in self.skel.Type.Members if e.Name == name][0]
        args=[]
        args2=RobotRaconteurPython.MessageElementDataUtil.VoidToMessageElementVector(args1)

        type2=RobotRaconteurPython.MemberDefinitionUtil.ToFunction(type1)
        for p in type2.Parameters:
            m=FindMessageElementByName(args2,p.Name)
            #m=[mm for mm in args2 if mm.ElementName==p.Name][0]
            a=UnpackMessageElement(m,p,node=self.skel.RRGetNode())
            args.append(a)
        exec('ret=self.obj.%s(*args)' % name)

        if (ret is None):
            m=RobotRaconteurPython.MessageElement()
            m.ElementName="return"
            m.ElementType=RobotRaconteurPython.DataTypes_void_t
            return RobotRaconteurPython.MessageElementDataUtil.MessageElementToVoid(m)
        return RobotRaconteurPython.MessageElementDataUtil.MessageElementToVoid(PackMessageElement(ret,type2.ReturnType,node=self.skel.RRGetNode()))


    def GetSubObj(self, name, index):

        type1=FindMemberByName(self.skel.Type.Members,name)
        #type1=[e for e in self.skel.Type.Members if e.Name == name][0]
        type2=RobotRaconteurPython.MemberDefinitionUtil.ToObjRef(type1)
        if (type2.IsArray or (type2.IsMap and type2.KeyType==RobotRaconteurPython.DataTypes_int32_t)):
            exec("obj,objecttype=self.obj.get_%s(unicode(index).encode('utf-8'))" % name)
        elif (type2.IsMap and type2.KeyType==RobotRaconteurPython.DataTypes_string_t):
            exec("obj,objecttype=self.obj.get_%s(unicode(index).encode('utf-8'))" % name)
        else:
            exec("obj,objecttype=self.obj.get_%s()" % name)

        director=WrappedServiceSkelDirectorPython(obj)
        rrobj=RobotRaconteurPython.WrappedRRObject(objecttype,director,0)
        director.__disown__()
        return RobotRaconteurPython.WrappedRRObjectUtil.WrappedRRObjectToVoid(rrobj)


    def GetArrayMemory(self,name):

        exec("m=self.obj.%s" % name)
        d=WrappedArrayMemoryDirectorPython(m)
        d.__disown__()
        return d


    def GetMultiDimArrayMemory(self,name):

        exec("m=self.obj.%s" % name)
        d=WrappedMultiDimArrayMemoryDirectorPython(m)
        d.__disown__()

        return d


    def MonitorEnter(self,timeout):

        self.obj.RobotRaconteurMonitorEnter(timeout)


    def MonitorExit(self):

        self.obj.RobotRaconteurMonitorExit()



    def ReleaseCastObj(self):
        self.obj=None
        self.skel=None

def skel_dispatchevent(skel,name,type1,*args):
    m=RobotRaconteurPython.vectorptr_messageelement()
    i=0
    node=skel.RRGetNode()
    for p in type1.Parameters:
        a=PackMessageElement(args[i],p,node=node)
        m.append(a)
        i+=1
    skel.WrappedDispatchEvent(name,m)

def skel_callbackcall(skel,name,type1,endpoint,*args):
    m=RobotRaconteurPython.vectorptr_messageelement()
    i=0
    node=skel.RRGetNode()
    for p in type1.Parameters:
        a=PackMessageElement(args[i],p,node)
        m.append(a)
        i+=1
    ret=skel.WrappedCallbackCall(name,endpoint,m)
    return UnpackMessageElement(ret,type1.ReturnType,node)

def skel_callbackcallvoid(skel,name,type1,endpoint,*args):
    m=RobotRaconteurPython.vectorptr_messageelement()
    i=0
    node=skel.RRGetNode()
    for p in type1.Parameters:
        a=PackMessageElement(args[i],p,node)
        m.append(a)
        i+=1
    skel.WrappedCallbackCall(name,endpoint,m)

class CallbackServer(object):
    def __init__(self,func):

        self.func=func
    def GetClientFunction(self,endpoint):
        func=self.func

        return lambda *args : func(endpoint,*args)



class WrappedArrayMemoryDirectorPython(RobotRaconteurPython.WrappedArrayMemoryDirector):
    def __init__(self,memory):
        self.memory=memory
        super(WrappedArrayMemoryDirectorPython,self).__init__()

    def Length(self):

        return self.memory.Length


    def Read(self,memorypos,buffer,bufferpos,count):

        buffer3=[0]*count
        self.memory.Read(memorypos,buffer3,bufferpos,count)
        buffer2=RobotRaconteurPython.MessageElementDataUtil.VoidToRRBaseArray(buffer)
        type1=RobotRaconteurPython.TypeDefinition()
        type1.Type=buffer2.GetTypeID()
        PackToRRArray(buffer3,type1,buffer2)



    def Write(self,memorypos,buffer,bufferpos,count):

        buffer2=RobotRaconteurPython.MessageElementDataUtil.VoidToRRBaseArray(buffer)
        buffer3=UnpackFromRRArray(buffer2,None)
        self.memory.Write(memorypos,buffer3,bufferpos,count)


class WrappedMultiDimArrayMemoryDirectorPython(RobotRaconteurPython.WrappedMultiDimArrayMemoryDirector):
    def __init__(self,memory):
        self.memory=memory
        super(WrappedMultiDimArrayMemoryDirectorPython,self).__init__()

    def Dimensions(self):

        d=self.memory.Dimensions
        d2=RobotRaconteurPython.vector_uint64_t()
        for d_i in d: d2.push_back(d_i)
        return d2


    def DimCount(self):

        return self.memory.DimCount


    def Complex(self):

        return self.memory.Complex


    def Read(self,p):

        rrmultidim=p.buffer
        rrt=RobotRaconteurPython.TypeDefinition()
        rrt.Type=rrmultidim.Real.GetTypeID()
        dims=list(p.count)
        elementcount=reduce(operator.mul,dims,1)
        if (not RobotRaconteur.UseNumPy):

            real=[0]*elementcount
            imag=None
            if (self.Complex()):
                imag=[0]*elementcount

            readdat1=MultiDimArray(dims,real,imag)

            self.memory.Read(list(p.memorypos),readdat1,list(p.bufferpos),dims)



            PackToRRArray(real,rrt,rrmultidim.Real)
            if (not imag is None):
                if (rrmultidim.Imag is None): raise Exception("Complex mismatch")
                PackToRRArray(imag,rrt,rrmultidim.Imag)
        else:

            if (not self.Complex()):
                readdat1=numpy.zeros(dims,dtype=RRTypeIdToNumPyDataType(rrmultidim.Real.GetTypeID()))
                self.memory.Read(list(p.memorypos),readdat1,list(p.bufferpos),dims)

                PackToRRArray(readdat1.flatten(order="F"),rrt,rrmultidim.Real)
            else:
                if (rrmultidim.Real.GetTypeID()==RobotRaconteurPython.DataTypes_double_t or rrmultidim.Real.GetType()==RobotRaconteurPython.DataTypes_single_t):
                    if (rrmultidim.Real.GetTypeID()==RobotRaconteurPython.DataTypes_double_t):
                        readdat1=numpy.zeros(dims,dtype=numpy.complex128)
                    else:
                        readdat1=numpy.zeros(dims,dtype=numpy.complex64)
                    self.memory.Read(list(p.memorypos),readdat1,list(p.bufferpos),dims)

                    PackToRRArray(readdat1.real.flatten(order="F"),rrt,rrmultidim.Real)
                    if (rrmultidim.Imag is None): raise Exception("Complex mismatch")
                    PackToRRArray(readdat1.imag.flatten(order="F"),rrt,rrmultidim.Imag)
                else:
                    readdat1=(numpy.zeros(dims,dtype=RRTypeIdToNumPyDataType(rrmultidim.Real.GetTypeID())),numpy.zeros(dims,dtype=RRTypeIdToNumPyDataType(rrmultidim.Real.GetTypeID())))
                    self.memory.Read(list(p.memorypos),readdat1,list(p.bufferpos),dims)

                    PackToRRArray(readdat1[0].flatten(order="F"),rrt,rrmultidim.Real)
                    if (rrmultidim.Imag is None): raise Exception("Complex mismatch")
                    PackToRRArray(readdat1[1].flatten(order="F"),rrt,rrmultidim.Imag)


    def Write(self,p):

        memorypos=list(p.memorypos)
        bufferpos=list(p.bufferpos)
        count=list(p.count)

        rrmultidim=p.buffer
        md_dims=UnpackFromRRArray(rrmultidim.Dims)
        md_real=UnpackFromRRArray(rrmultidim.Real)
        md_imag=UnpackFromRRArray(rrmultidim.Imag)
        if (not RobotRaconteur.UseNumPy):
            buffer=MultiDimArray(md_dims,md_real,md_imag)
            self.memory.Write(memorypos,buffer,bufferpos,count)
        else:
            if (md_imag==None):
                buffer=md_real.reshape(count,order="F")
                self.memory.Write(memorypos,buffer,bufferpos,count)
            else:
                if (md_imag.dtype==numpy.float64 or md_imag.dtype==numpy.float32):
                    buffer=md_real.reshape(count,order="F") + 1j*md_imag.reshape(count,order="F")
                    self.memory.Write(memorypos,buffer,bufferpos,count)
                else:
                    buffer=(md_real.reshape(count,order="F"), md_imag.reshape(count,order="F"))
                    self.memory.Write(memorypos,buffer,bufferpos,count)




class WrappedClientServiceListenerDirector(RobotRaconteurPython.ClientServiceListenerDirector):
    def __init__(self,callback):
        self.callback=callback

        super(WrappedClientServiceListenerDirector,self).__init__()

    def Callback(self,code):

       self.callback(self.stub,code,None)


class WrappedServerServiceListenerDirector(RobotRaconteurPython.ServerServiceListenerDirector):
    def __init__(self,callback,context):
        self.callback=callback
        self.context=context

        super(WrappedServerServiceListenerDirector,self).__init__()

    def Callback(self,code,endpoint):

        self.callback(self.context,code,endpoint)


def NumPyDataTypeToRRTypeId(id):
    if (id==numpy.float64 ):
        return RobotRaconteurPython.DataTypes_double_t
    elif (id==numpy.float32):
        return RobotRaconteurPython.DataTypes_single_t
    elif (id==numpy.int8):
        return RobotRaconteurPython.DataTypes_int8_t
    elif (id==numpy.uint8):
        return RobotRaconteurPython.DataTypes_uint8_t
    elif (id==numpy.int16):
        return RobotRaconteurPython.DataTypes_int8_t
    elif (id==numpy.uint16):
        return RobotRaconteurPython.DataTypes_uint8_t
    elif (id==numpy.int32):
        return RobotRaconteurPython.DataTypes_int8_t
    elif (id==numpy.uint32):
        return RobotRaconteurPython.DataTypes_uint8_t
    elif (id==numpy.int64):
        return RobotRaconteurPython.DataTypes_int8_t
    elif (id==numpy.uint64):
        return RobotRaconteurPython.DataTypes_uint8_t
    raise Exception("Unknown numpy data type")

def RRTypeIdToNumPyDataType(id):
    if (id==RobotRaconteurPython.DataTypes_double_t):
        return numpy.float64
    elif (id==RobotRaconteurPython.DataTypes_single_t):
        return numpy.float32
    elif (id==RobotRaconteurPython.DataTypes_int8_t):
        return numpy.int8
    elif (id==RobotRaconteurPython.DataTypes_uint8_t):
        return numpy.uint8
    elif (id==RobotRaconteurPython.DataTypes_int16_t):
        return numpy.int16
    elif (id==RobotRaconteurPython.DataTypes_uint16_t):
        return numpy.uint16
    elif (id==RobotRaconteurPython.DataTypes_int32_t):
        return numpy.int32
    elif (id==RobotRaconteurPython.DataTypes_uint32_t):
        return numpy.uint32
    elif (id==RobotRaconteurPython.DataTypes_int64_t):
        return numpy.int64
    elif (id==RobotRaconteurPython.DataTypes_uint64_t):
        return numpy.uint64
    raise Exception("Unknown Robot Raconteur data type")

def PackToRRArray_numpy(array,type1,destrrarray=None):

    if (array is None): return None
    if (array.ndim > 1): raise Exception("Array  must be single dimensional")
    if( not(type1.Type>=RobotRaconteurPython.DataTypes_double_t and type1.Type <= RobotRaconteurPython.DataTypes_string_t)):
        raise Exception('Invalid argument type')

    packs1=RRTypeIdToNumPyDataType(type1.Type)

    if (destrrarray==None):
        out=RobotRaconteurPython.AllocateRRArrayByType(type1.Type,len(array))
    else:
        if (destrrarray.GetTypeID() != type1.Type): raise Exception("Incorrect destrrarray data type")
        if (destrrarray.Length() !=len(array)): raise Exception("Incorrect destrrarray length")
        out=destrrarray

    c_out1=(ctypes.c_ubyte*(out.Length()*out.ElementSize())).from_address(out.void_ptr())
    c_out=numpy.frombuffer(c_out1,dtype=packs1)

    #numpy.copyto(array,c_out)
    c_out[:]=array
    #struct.pack_into("=" + str(len(array)) + packs1,c_out,0,*array)
    return out

def UnpackFromRRArray_numpy(rrarray,type1=None):
    if (rrarray is None): return None
    typeid=rrarray.GetTypeID()
    if (not type1 is None):
        if (typeid != type1.Type): raise RobotRaconteurPython.DataTypeMismatchException("Data type mismatch")
    if( not(typeid>=RobotRaconteurPython.DataTypes_double_t and typeid <= RobotRaconteurPython.DataTypes_string_t)):
        raise Exception('Invalid argument type')

    packs1=RRTypeIdToNumPyDataType(typeid)


    c_rrarray1=(ctypes.c_ubyte*(rrarray.Length()*rrarray.ElementSize())).from_address(rrarray.void_ptr())
    c_rrarray=numpy.frombuffer(c_rrarray1,dtype=packs1)
    value=numpy.empty(rrarray.Length(),dtype=packs1)
    value[:]=c_rrarray
    #value= struct.unpack_from("=" + str(rrarray.Length()) + packs1,c_rrarray,0)
    #if (packs1=='s'):
        #return value[0]
    return value
def PackToRRMultiDimArray_numpy(element, data, type1):
    element.ElementType=RobotRaconteurPython.DataTypes_multidimarray_t
    iset=RobotRaconteurPython.vectorptr_messageelement()
    type1_r=RobotRaconteurPython.TypeDefinition()
    type1_r.FromString(type1.ToString())
    type1_r.Name="real"
    type1_r.IsMultidimArray=False
    type1_i=RobotRaconteurPython.TypeDefinition()
    type1_i.FromString(type1.ToString())
    type1_i.Name="imag"
    type1_i.IsMultidimArray=False
    typeid=type1.Type
    if(typeid>=RobotRaconteurPython.DataTypes_int8_t and typeid <= RobotRaconteurPython.DataTypes_uint64_t):
        if ((type(data) is list) or (type(data) is set) or (type(data) is tuple)):
            real=data[0]
            imag=data[1]
            if (real.size != imag.size): raise Exception("real and imag must have same size")
            iset.append(PackMessageElement(real.ndim, "int32 dimcount"))
            iset.append(PackMessageElement(real.shape, "int32[] dims"))
            iset.append(PackMessageElement(real.flatten(order="F"),type1_r))
            iset.append(PackMessageElement(imag.flatten(order="F"),type1_i))
            element.DataCount=4
        else:
            iset.append(PackMessageElement(data.ndim, "int32 dimcount"))
            iset.append(PackMessageElement(data.shape, "int32[] dims"))
            iset.append(PackMessageElement(data.flatten(order="F"),type1_r))
            element.DataCount=3
        element.SetData(RobotRaconteurPython.MessageElementMultiDimArray(iset))
        return
    if(typeid>=RobotRaconteurPython.DataTypes_double_t and typeid <= RobotRaconteurPython.DataTypes_single_t):
        iset.append(PackMessageElement(data.ndim, "int32 dimcount"))
        iset.append(PackMessageElement(data.shape, "int32[] dims"))
        if (typeid==RobotRaconteurPython.DataTypes_double_t):
            if (data.dtype==numpy.complex128):
                real=data.real
                imag=data.imag
                iset.append(PackMessageElement(real.flatten(order="F"),type1_r))
                iset.append(PackMessageElement(imag.flatten(order="F"),type1_i))
            else:
                iset.append(PackMessageElement(data.flatten(order="F"),type1_r))
            element.SetData(RobotRaconteurPython.MessageElementMultiDimArray(iset))
            return
        if (typeid==RobotRaconteurPython.DataTypes_single_t):
            if (data.dtype==numpy.complex64):
                real=data.real
                imag=data.imag
                iset.append(PackMessageElement(real.flatten(order="F"),type1_r))
                iset.append(PackMessageElement(imag.flatten(order="F"),type1_i))
            else:
                iset.append(PackMessageElement(data.flatten(order="F"),type1_r))
            element.SetData(RobotRaconteurPython.MessageElementMultiDimArray(iset))
            return
    raise Exception("Could not pack numpy ndarray")

def UnpackFromRRMultiDimArray(element):
    Dims=UnpackMessageElement(FindMessageElementByName(element.GetData().Elements,'dims'),'int32[] dims')
    #Dims=UnpackMessageElement([e for e in element.GetData().Elements if e.ElementName=='dims'][0],'int32[] dims')
    DimCount=UnpackMessageElement(FindMessageElementByName(element.GetData().Elements,'dimcount'),'int32 dimcount')
    #DimCount=UnpackMessageElement([e for e in element.GetData().Elements if e.ElementName=='dimcount'][0],'int32 dimcount')
    if (len(Dims) !=DimCount): raise Exception('MultiDimArray mismatch')
    Real=UnpackMessageElement(FindMessageElementByName(element.GetData().Elements,'real'))
    #Real=UnpackMessageElement([e for e in element.GetData().Elements if e.ElementName=='real'][0])
    imag_search=[e for e in element.GetData().Elements if e.ElementName=='imag']
    if (len(imag_search)>0):

        Imag=UnpackMessageElement(imag_search[0])
        if (Real.dtype==numpy.float64 or Real.dtype==numpy.float32):
            return Real.reshape(Dims,order="F") + (Imag.reshape(Dims,order="F")*1j)
        else:
            return (Real.reshape(Dims,order="F"),Imag.reshape(Dims,order="F"))

    else:

        return Real.reshape(Dims,order="F")

def VerifyMultiDimArrayLength(data,type1):
    if (len(type1.MultiDimLength)!=data.DimCount or data.DimCount != len(data.Dims)):
        raise Exception("Array dimension mismatch")
    count=1
    for i in xrange(data.DimCount):
        count*=data.Dims[i]
        if (data.Dims[i] !=type1.MultiDimLength[i]):
            raise Exception("Array dimension mismatch")

    if (len(data.Real)!=count): raise Exception("Array dimension mismatch")
    if (data.Complex): raise Exception("Fixed dimension arrays must not be complex")
    if (data.Imag is not None): raise Exception("Fixed dimension arrays must not be complex")

def VerifyMultiDimArrayLength_numpy(data,type1):

    if ((type(data) is list) or (type(data) is set) or (type(data) is tuple)):
        raise Exception("Fixed dimension arrays must not be complex")

    if (len(type1.MultiDimLength)!=data.ndim):
        raise Exception("Array dimension mismatch")
    count=1
    for i in xrange(data.ndim):
        count*=data.shape[i]
        if (data.shape[i] !=type1.MultiDimLength[i]):
            raise Exception("Array dimension mismatch")



    if (data.dtype==numpy.complex64 or data.dtype==numpy.complex128):
        raise Exception("Fixed dimension arrays must not be complex")



class RRConstants(object):
    pass

def convert_constant(const):
    s2=const.split(None,3)
    t=RobotRaconteurPython.TypeDefinition()
    t.FromString(s2[1])

    if (t.Type==RobotRaconteurPython.DataTypes_string_t):
        return s2[2], s2[3].strip('"')

    if (t.Type >= RobotRaconteurPython.DataTypes_double_t and t.Type <= RobotRaconteurPython.DataTypes_uint64_t):
        if (t.IsMultidimArray or t.IsMap):
            error("Invalid constant type")
        if (t.Type==RobotRaconteurPython.DataTypes_double_t or t.Type==RobotRaconteurPython.DataTypes_single_t):
            if (t.IsArray):
                s3=s2[3].strip().lstrip('{').rstrip('}')
                return s2[2], [float(i) for i in s3.split(',')]
            else:
                return s2[2], float(s2[3])
        else:
            if (t.IsArray):
                s3=s2[3].strip().lstrip('{').rstrip('}')
                return s2[2], [int(i) for i in s3.split(',')]
            else:
                return s2[2], int(s2[3])


def ServiceDefinitionConstants(servicedef):
    o=dict()
    for s in servicedef.Options:
        s2=s.split(None,3)
        if (s2[0]=="constant"):
            name,val=convert_constant(s)
            o[name]=val

    for e in servicedef.Objects:
        o2=dict()
        for s in e.Options:

            s2=s.split(None,3)
            if (s2[0]=="constant"):
                name,val=convert_constant(s)
                o2[name]=val
        if (len(o2)>0):
            o[e.Name]=o2

    cobj=RRConstants()
    for k,v in o.items():

        if not isinstance(v, dict):
            cobj.__dict__[k]=v
        else:
            cobj2=RRConstants()
            for k2,v2 in v.items():
                cobj2.__dict__[k2]=v2
            cobj.__dict__[k]=cobj2
    return cobj

def adjust_timeout(t):
    if (t<0):
        return -1
    else:
        return int(t*1000)

class AsyncStubReturnDirector(RobotRaconteurPython.AsyncHandlerDirector):
    def __init__(self,handler):
        super(AsyncStubReturnDirector,self).__init__()
        self._handler=handler

    def handler(self, innerstub, error_code,errorname,errormessage):
        if (error_code!=0):
            err=RobotRaconteurPythonError.RobotRaconteurExceptionUtil.ErrorCodeToException(error_code,errorname,errormessage)
            self._handler(None,err)
            return
        try:
            innerstub2=RobotRaconteurPython.WrappedServiceUtil.VoidToWrappedServiceStub(innerstub)
            stub=innerstub2.GetPyStub()
            if (stub is None):
                stub=InitStub(innerstub2)
                innerstub2.SetPyStub(stub)
        except Exception as err2:
            self._handler(None, err2)
            return
        self._handler(stub, None)

class AsyncVoidNoErrReturnDirector(RobotRaconteurPython.AsyncHandlerDirector):
    def __init__(self,handler):
        super(AsyncVoidNoErrReturnDirector,self).__init__()
        self._handler=handler

    def handler(self, innerstub, error_code,errorname,errormessage):
        self._handler()

class AsyncStringReturnDirector(RobotRaconteurPython.AsyncHandlerDirector):
    def __init__(self,handler):
        super(AsyncStringReturnDirector,self).__init__()
        self._handler=handler

    def handler(self, istr, error_code,errorname,errormessage):
        if (error_code!=0):
            err=RobotRaconteurPythonError.RobotRaconteurExceptionUtil.ErrorCodeToException(error_code,errorname,errormessage)
            self._handler(None,err)
            return
        try:
            istr2=RobotRaconteurPython.WrappedServiceUtil.VoidToString(istr)

        except Exception as err2:
            self._handler(None, err2)
            return
        self._handler(istr2, None)

class AsyncTimerEventReturnDirector(RobotRaconteurPython.AsyncHandlerDirector):
    def __init__(self,handler):
        super(AsyncTimerEventReturnDirector,self).__init__()
        self._handler=handler

    def handler(self, ev, error_code, errorname, errormessage):
        ev2=RobotRaconteurPython.WrappedServiceUtil.VoidToTimerEvent(ev)
        self._handler(ev2)

def defered_handler(deferred, noerror, *args):
    if (noerror):
        if (len(args)==0):
            reactor.callFromThread(deferred.callback,None)
        else:
            reactor.callFromThread(deferred.callback,args[0])
    else:
        if (len(args)==1):
            if (args[0] is None):
                reactor.callFromThread(deferred.callback,None)
            else:
                reactor.callFromThread(deferred.errback,args[0])
        else:
            if (args[1] is None):
                reactor.callFromThread(deferred.callback,args[0])
            else:
                reactor.callFromThread(deferred.errback,args[1])


def async_call(func, args, directorclass, handler, noerror=False, directorargs=()):
    d=None
    if (handler is None):
        if (not hastwisted):
            raise Exception("Twisted not found. ""handler"" cannot be None")
        d=Deferred()
        handler=functools.partial(defered_handler,d,noerror)
    handler2=directorclass(handler,*directorargs)
    args2=list(args)
    args2.extend([handler2,0])
    handler2.__disown__()
    func(*args2)
    return d

class ExceptionHandlerDirector(RobotRaconteurPython.AsyncHandlerDirector):
    def __init__(self,handler):
        super(ExceptionHandlerDirector,self).__init__()
        self._handler=handler

    def handler(self, istr, error_code,errorname,errormessage):
        if (error_code!=0):
            err=RobotRaconteurPythonError.RobotRaconteurExceptionUtil.ErrorCodeToException(error_code,errorname,errormessage)
            self._handler(err)
            return

class PipeBroadcaster(object):
    class _connected_endpoint(object):
        def __init__(self,ep):
            self.backlog=[]
            self.forward_backlog=[]
            self.endpoint=ep
            self.sending=False
            self.active_sends=[]
            self.active_send_count=0

    def __init__(self,pipe,maximum_backlog=-1):
        self.pipe=pipe
        self.endpoints=[]
        self.endpoints_lock=threading.Lock()
        self.maximum_backlog=maximum_backlog;
        self.pipe.PipeConnectCallback=self.EndpointConnected

    def EndpointConnected(self,ep):
        with self.endpoints_lock:
            cep=PipeBroadcaster._connected_endpoint(ep)
            ep.PipeEndpointClosedCallback=functools.partial(self.EndpointClosed,cep)
            ep.IgnoreReceived=True
            ep.PacketAckReceivedEvent+=functools.partial(self.PacketAckReceived,cep)
            ep.RequestPacketAck=True
            self.endpoints.append(cep)

    def EndpointClosed(self,ep):
        with self.endpoints_lock:
            self.endpoints.remove(ep)    

    def PacketAckReceived(self,ep,e,ind):

        with self.endpoints_lock:
            if (ind in ep.backlog):
                ep.backlog.remove(ind)
            else:
                ep.forward_backlog.append(ind)


    def AsyncSendPacket(self, packet, handler):
        keys=[]
        keys_lock=threading.Lock()

        d=None
        if (handler is None):
            if (not hastwisted):
                raise Exception("Twisted not found. ""handler"" cannot be None")
            d=Deferred()
            handler=functools.partial(reactor.callFromThread,d.callback)

        def handle_send(ep,key,send_key,id,err):
            with self.endpoints_lock:
                ep.active_sends.remove(send_key)
                if (self.maximum_backlog != -1):

                    if (id in ep.forward_backlog):
                        ep.forward_backlog.remove(id)
                    else:
                        ep.backlog.append(id)
            with keys_lock:
                keys.remove(key)
                if (len(keys)!=0): return
            try:
                handler()
            except: pass

        with self.endpoints_lock, keys_lock:
            count=0
            for ee in self.endpoints:
                try:

                    if (self.maximum_backlog!=-1 and len(ee.backlog) + len(ee.active_sends) > self.maximum_backlog):
                        continue
                    if (ee.active_send_count > 1e9):
                        ee.active_send_count=0
                    else:
                        ee.active_send_count+=1
                    send_key=ee.active_send_count
                    ee.active_sends.append(send_key)
                    ee.endpoint.AsyncSendPacket(packet,functools.partial(handle_send,ee,count,send_key))
                    keys.append(count)
                    count+=1
                except:
                    pass
        return d

    def SendPacket(self, packet):
        l=threading.Event()
        def handler():
            l.set()
        self.AsyncSendPacket(packet,handler)
        l.wait()
        
    @property
    def ActivePipeEndpointCount(self):
        with self.endpoints_lock:
            return len(self.endpoints)

class WireBroadcaster(object):
    def __init__(self, wire):
        self._connected_wires=[]
        self._connected_wires_lock=threading.Lock()
        self._wire=wire
        self._wire.WireConnectCallback=self.ConnectionConnected

    def ConnectionConnected(self, ep):
        with self._connected_wires_lock:
            ep.IgnoreInValue=True
            ep.WireConnectionClosedCallback=self.ConnectionClosed
            self._connected_wires.append(ep)

    def ConnectionClosed(self, ep):
        with self._connected_wires_lock:
            self._connected_wires.remove(ep)

    @property
    def OutValue(self):
        raise Exception("Write only property")

    @OutValue.setter
    def OutValue(self, value):
        with self._connected_wires_lock:
            for w in self._connected_wires:
                try:
                    w.OutValue=value
                except:
                    pass
                
    @property
    def ActiveWireConnectionCount(self):
        with self._connected_wires_lock:
            return len(self._connected_wires)

_trace_hook=sys.gettrace()

def settrace():
    #This function enables debugging for the threads started by the ThreadPool
    #You may see a warning in Eclipse; it can safely be ignored.
    t=_trace_hook
    if (t is not None):
        sys.settrace(t)





import RobotRaconteurPython
import RobotRaconteurPythonError
import RobotRaconteur